//NOTE: Rememember to add all the classes to brickClasses
//		at the bottom of this file

/**
	Brick Movement Algorithm:
		

*/

class Brick extends Sprite{
	constructor(texture, x, y){
		//use default brick texture if no texture specified
		//in order to make sure the shape is the right size
		if (!texture)
			texture = "brick_main_0_0";

		super(texture, x, y);
		this.createShape();

		this.patch = {
			shield: {},
			move: null,
			storedMove: null,
			invisible: false,
			antilaser: null,
		}

		this.health = 10;
		this.armor = 0;

		this.hitSound = "brick_armor";
		this.deathSound = "brick_hit";

		this.gameType = "brick";
		this.brickType = "brick";
	}

	initPatches(newPatch){
		if (!newPatch)
			return;
		let p = newPatch;

		//shields
		if (p[0] === 0)
			this.initShield("up");
		if (p[1] === 0)
			this.initShield("down");
		if (p[2] === 0)
			this.initShield("left");
		if (p[3] === 0)
			this.initShield("right");

		//movement
		let move = this.patch.move;
		if (p[4] !== undefined)
			this.initMovementPatch(p[4]);

		//invisible
		if (p[5] === 0){
			this.patch.invisible = true;
			this.visible = false;
		}

		//antilaser
		if (p[6] === 0){
			let laserShield = new Sprite("patch_1_0");
			laserShield.scale.set(1);
			this.addChild(laserShield);
			this.patch.antilaser = true;
		}
	}

	initShield(dir){
		let column = {
			up: 4,
			down: 5,
			left: 6,
			right: 7
		}
		let shield = new Sprite(`patch_0_${column[dir]}`);
		shield.scale.set(1);
		shield.addAnim("shine", "shield_shine_" + dir, 0.5);
		this.patch.shield[dir] = shield;
		this.addChild(shield);
	}

	initMovementPatch(value){
		let hit = (value >= 12);
		let n = value % 12;
		let i = Math.floor(n / 3); //dir
		let j = n % 3; //speed

		let speeds = [0.05, 0.1, 0.2];
		let vectors = [[0,-1], [0,1], [-1,0], [1,0]];

		let spd = speeds[j];
		let [vx, vy] = vectors[i];
		vx *= spd;
		vy *= spd;

		let move = {vx, vy};
		if (hit)
			this.patch.storedMove = move;
		else
			this.patch.move = move;
		
	}

	isMoving(){
		//check both movement patch and velocity
		return (this.patch.move || this.vx || this.vy);
	}

	static getHitSide(norm){
		let rad = Math.atan2(norm.y, norm.x);
		let deg = rad * 180 / Math.PI;
		if (deg >= -135 && deg < -45)
			return "up";
		if (deg >= -45 && deg < 45)
			return "right";
		if (deg >= 45 && deg < 135)
			return "down";
		return "left";
	}

	checkBallHit(ball){
		//check if bounding boxes overlap
		if (!this.checkOverlap(ball))
			return [false];
		//then use SAT collision check
		let resp = ball.checkCollision(this);
		if (!resp[0])
			return [false];
		//check if the collision is valid
		//(the ball shouldn't be moving away from the brick)
		let norm = resp[1];
		if (!ball.validCollision(norm.x, norm.y))
			return [false];
		return resp;
	}

	invisReveal(){
		let tex = this.texture;
		let rect = tex.frame;
		for (let i = 0; i < 30; i++){
			let dx = randRange(0, 13);
			let dy = randRange(0, 5);
			let x = rect.x + dx;
			let y = rect.y + dy;
			let rad = Math.random() * Math.PI * 2;
			let mag = 0.05 + Math.random() * 0.15;
			let [vx, vy] = Vector.rotate(0, mag, rad);
			let rect2 = new PIXI.Rectangle(x, y, 2, 2);
			let tex2 = new PIXI.Texture(tex, rect2);
			dx *= Math.random() * 4 - 2;
			dy *= Math.random() * 4 - 2;
			let p = new Particle(tex2, this.x + dx, this.y + dy, vx, vy);
			p.ay = 0.001;
			game.emplace("particles", p);
		}
		playSound("invisible_reveal");
	}

	//returns true if the brick will take damage
	handlePatches(obj, norm){
		let patch = this.patch;

		if (patch.storedMove){
			patch.move = patch.storedMove;
			patch.storedMove = null;
		}

		if (patch.invisible){
			patch.invisible = false;
			this.visible = true;
			this.invisReveal();
			if (obj.strength < this.armor || 
				obj.damage < this.health + 10)
				return false;
		}

		let dir = Brick.getHitSide(norm);
		let shield = patch.shield[dir];
		if (shield && obj.strength < 1){
			shield.playAnim("shine");
			return false;
		}

		if (patch.antilaser && obj.isLaser){
			playSound("antilaser_hit");
			return false;
		}
		return true;
	}

	//makes the ball bounce off the brick
	//also moves the ball back so it isn't overlapping 
	//the brick anymore
	onBallHit(ball, norm, mag){
		if (this.handlePatches(ball, norm))
			this.takeDamage(ball.damage, ball.strength);
		ball.onBrickHit(this, norm, mag);
	}

	checkProjectileHit(proj){
		if (!this.checkOverlap(proj))
			return [false];
		let resp = proj.checkCollision(this);
		//maybe add valid collision for ball projectiles
		return resp;
	}

	onProjectileHit(proj, norm, mag){
		if (this.handlePatches(proj, norm))
			this.takeDamage(proj.damage, proj.strength);
		proj.onBrickHit(this, norm, mag);
	}

	takeDamage(damage, strength){
		if (strength >= this.armor){
			this.health -= damage;
		}
		if (this.health <= 0)
			playSound(this.deathSound);
		else
			playSound(this.hitSound);
	}

	isDead(){
		return (this.health <= 0);
	}
}

class NormalBrick extends Brick{
	constructor(x, y, i, j){
		let tex = "brick_main_" + i + "_" + j;
		super(tex, x, y);
		this.normalInfo = {i, j};

		this.brickType = "normal";
	}
}

class MetalBrick extends Brick{
	//level should be [1-6]
	constructor(x, y, level){
		let j = level;
		let str = "brick_main_6_" + j;
		super(str, x, y);

		let anistr = `brick_shine_${3+level}`;
		this.addAnim("shine", anistr, 0.25);

		this.level = level;
		this.health = (level + 1) * 10;
	}

	takeDamage(damage, strength){
		super.takeDamage(damage, strength);
		this.playAnim("shine");
	}
}

class GoldBrick extends Brick{
	constructor(x, y, plated){
		let tex = "brick_main_6_0";
		if (plated)
			tex = "brick_main_6_7";
		super(tex, x, y);
		this.plated = plated;
		this.health = 100;
		this.armor = 1;

		this.addAnim("shine", "brick_shine_3", 0.25);
		this.addAnim("plated_shine", "brick_shine_10", 0.25);

		this.brickType = "gold";
	}

	takeDamage(damage, strength){
		super.takeDamage(damage, strength);
		if (this.plated){
			this.playAnim("plated_shine");
			if (strength >= 0){
				this.plated = false;
				this.setTexture("brick_main_6_0");
			}
		}
		else{
			this.playAnim("shine");
		}
	}
}

class PlatinumBrick extends Brick{
	constructor(x, y){
		super("brick_main_6_10", x, y);
		this.health = 100;
		this.armor = 2;

		this.addAnim("shine", "brick_shine_13", 0.25);

		this.brickType = "platinum";
	}

	takeDamage(damage, strength){
		super.takeDamage(damage, strength);
		this.playAnim("shine");
	}
}

class SpeedBrick extends Brick{
	constructor(x, y, gold, fast){
		let suffix = fast ? "8_12" : "8_13";
		if (gold)
			suffix = fast ? "6_8" : "6_9";
		super("brick_main_" + suffix, x, y);

		if (gold){
			this.health = 100;
			this.armor = 1;
			let j = fast ? 11 : 12;
			let anistr = "brick_shine_" + j;
			this.addAnim("shine", anistr, 0.25);
		}

		this.gold = gold;
		this.fast = fast;
		this.deltaSpeed = fast ? 0.05 : -0.05;

		this.brickType = "speed";
	}

	onBallHit(ball, norm, mag){
		super.onBallHit(ball, norm, mag);
		ball.setSpeed(ball.getSpeed() + this.deltaSpeed);
	}

	takeDamage(damage, strength){
		super.takeDamage(damage, strength);
		if (this.gold)
			this.playAnim("shine");
	}
}

class CopperBrick extends Brick{
	constructor(x, y){
		super("brick_main_6_11", x, y);

		this.health = 100;
		this.armor = 1;

		this.addAnim("shine", "brick_shine_14", 0.25);

		this.brickType = "copper";
	}

	onBallHit(ball, norm, mag){
		super.onBallHit(ball, norm, mag);

		let vx = ball.vx;
		let vy = ball.vy;
		let perp1 = norm.perpendicular();
		let perp2 = perp1.scale(-1);
		let dr1 = Vector.angleBetween(
			vx, vy, perp1.x, perp1.y
		);
		let dr2 = Vector.angleBetween(
			vx, vy, perp2.x, perp2.y
		);
		let range = Math.min(dr1, dr2) * 0.75;
		// console.log("copper " + (range * 180/Math.PI));
		let rad = Math.random() * range * 2 - range;
		ball.rotateVel(rad);
	}

	takeDamage(damage, strength){
		super.takeDamage(damage, strength);
		this.playAnim("shine");
	}
}

class DetonatorBrick extends Brick{
	//detonator types: normal, neo, freeze
	constructor(x, y, detType="normal"){
		super("brick_main_7_3", x, y);
		
		this.addAnim("glow", "brick_glow_0", 0.25, true);
		this.playAnim("glow");

		this.deathSound = "detonator_explode";

		this.detType = detType;
		this.brickType = "detonator";
	}

	onDeath(){
		//invisible explosion projectile
		game.top.emplaceCallback(50, () => {
			game.emplace("projectiles", new Explosion(
				this.x, this.y, 16*3-1, 8*3-1
			));
		});

		//explosion smoke particle
		let i = Math.floor(Math.random() * 4);
		let tex = "det_smoke_reg_" + i;
		let smoke = new Particle(tex, this.x, this.y);
		smoke.setGrowth(0.01, -0.00002);
		smoke.setFade(0.005);
		game.emplace("particles", smoke);

		//explosion blast particle
		let blast = new Particle(null, this.x, this.y);
		let anistr = [];
		for (let i = 0; i < 7; i++)
			anistr.push(`det_blast_${i}_0`);
		blast.addAnim("blast", anistr, 0.5);
		blast.playAnim("blast");
		blast.dieOnAniFinish = true;
		game.emplace("particles", blast);
	}
}

var brickClasses = {
	Brick,
	NormalBrick,
	MetalBrick,
	GoldBrick,
	PlatinumBrick,
	SpeedBrick,
	CopperBrick,
	DetonatorBrick,
}