class Enemy extends Sprite{
	constructor(texture, x, y, vx, vy){
		super(texture, x, y, vx, vy);
		this.createShape();
		this.setState("emerging");

		this.gameType = "enemy";
	}

	setState(name, ...args){
		let state = Enemy.states[name];
		this.state = {
			name: name,
			init: state.init.bind(this),
			update: state.update.bind(this)
		}
		this.state.init(...args);
	}

	advanceState(){
		this.state = null;
	}

	checkBallHit(ball){
		//check if bounding boxes overlap
		if (!this.checkOverlap(ball))
			return [false];
		//then use SAT collision check
		let resp = ball.checkCollision(this);
		if (!resp[0])
			return [false];
		//check if the collision is valid
		//(the ball shouldn't be moving away from the brick)
		let norm = resp[1];
		if (!ball.validCollision(norm.x, norm.y))
			return [false];
		return resp;
	}

	onBallHit(ball, norm, mag){
		this.kill();
		ball.onEnemyHit(this, norm, mag);
	}

	checkProjectileHit(proj){
		if (!this.checkOverlap(proj))
			return [false];
		let resp = proj.checkCollision(this);
		//maybe add valid collision for ball projectiles
		return resp;
	}

	onProjectileHit(proj, norm, mag){
		this.kill();
		proj.onEnemyHit(this, norm, mag);
	}

	update(delta){
		if (this.y - this.height/2 > DIM.w)
			this.kill();

		if (this.state){
			this.state.update(delta);
		}
		super.update(delta);
	}

}

class Dropper extends Enemy{
	//position will be set by the Gates
	constructor(id){
		let i = Math.floor(id/3);
		let j = id % 3;
		super(`dropper_${i}_${j}`);
		this.menacerId = id;

		let yoff = 7;
		if (id == 0 || id == 4)
			yoff = 6;
		let deg = randRange(-60, 60);
		let rad = deg * Math.PI / 180;
		let [vx, vy] = Vector.rotate(0, 0.2, rad);
		let menacer = new Menacer(
			this.x, this.y + yoff, vx, vy, id
		);
		menacer.scale.set(1);
		this.addChild(menacer);
		this.menacer = menacer;
	}

	advanceState(){
		this.state = null;
		let deg = 90 - randRange(10, 30);
		deg *= (Math.random() > 0.5) ? 1 : -1;
		let rad = deg * Math.PI / 180;
		let [vx, vy] = Vector.rotate(0, 0.1, rad);
		this.vx = vx;
		this.vy = vy;
	}

	canRelease(){
		if (!this.menacer || this.state)
			return false;

	}

	releaseMenacer(){
		if (!this.menacer || this.state)
			return;

		let m = this.menacer;
		this.menacer = null;
		this.removeChild(m);
		m.scale.set(2);
		//need to multiply offset by 2
		m.moveTo(this.x, 2*m.y + this.y);
		game.emplace("menacers", m);
	}

	update(delta){
		let [x0, y0, x1, y1] = this.shape.getAABB();
		if (x0 < DIM.lwallx)
			this.vx = Math.abs(this.vx);
		else if (x1 > DIM.rwallx)
			this.vx = -Math.abs(this.vx);

		let paddle = game.get("paddles")[0];
		let [px0, py0, px1, py1] = paddle.shape.getAABB();
		if (this.x > px0 && this.x < px1)
			this.releaseMenacer();

		super.update(delta);
	}
}

class Menacer extends Ball{
	constructor(x, y, vx, vy, id){
		super(x, y, vx, vy);
		this.setTexture(`ball_main_0_${3+id}`);
		this.menacerId = id;

		this.gameType = "menacer";
	}
}

Enemy.states = {
	emerging: {
		//I'm going to try to use function binding
		init(spd=0.05){
			this.vx = 0;
			this.vy = spd;
		},
		update(delta){
			if (this.y - this.height/2 > DIM.ceiling){
				this.advanceState();
			}
		}
	}
}